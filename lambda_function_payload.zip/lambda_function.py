import json
import os
import urllib.request

def lambda_handler(event, context):
    bot_token = os.environ.get("TELEGRAM_BOT_TOKEN")
    chat_id = os.environ.get("TELEGRAM_CHAT_ID")

    for record in event.get("Records", []):
        sns_msg = record.get("Sns", {}).get("Message", "")
        subject = record.get("Sns", {}).get("Subject", "AWS Cards Service Alert")

        text = f"🚨 *{subject}*\n\n{sns_msg}"

        if bot_token and chat_id:
            url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
            payload = json.dumps({
                "chat_id": chat_id,
                "text": text
            }).encode("utf-8")
            req = urllib.request.Request(url, data=payload, headers={"Content-Type": "application/json"})
            try:
                with urllib.request.urlopen(req) as resp:
                    print("Dispatched to Telegram successfully:", resp.read().decode())
            except Exception as e:
                print("Failed to dispatch to Telegram:", e)

    return {"statusCode": 200, "body": "Alert processed"}
