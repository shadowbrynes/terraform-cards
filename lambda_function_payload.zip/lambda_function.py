import json

def lambda_handler(event, context):
    print('Received CloudWatch Alarm via SNS:', json.dumps(event))
    return {'statusCode': 200, 'body': 'Alert processed'}
